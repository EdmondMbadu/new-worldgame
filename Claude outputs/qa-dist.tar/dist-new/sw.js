const CACHE = 'last-light-931fb061325f';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('last-light-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET' || request.headers.has('range')) return;
  const url = new URL(request.url);
  if (url.origin !== location.origin || !url.pathname.startsWith(new URL(self.registration.scope).pathname)) return;
  if (url.pathname.endsWith('/sw.js')) return;
  const page = request.mode === 'navigate' || url.pathname.endsWith('/') || url.pathname.endsWith('.html');
  const store = (response) => {
    if (response.ok && response.status === 200 && response.type === 'basic') {
      const copy = response.clone();
      caches.open(CACHE).then((cache) => cache.put(request, copy));
    }
    return response;
  };
  event.respondWith(
    page
      ? fetch(request).then(store).catch(() => caches.match(request).then((hit) => hit || Response.error()))
      : caches.match(request).then((hit) => hit || fetch(request).then(store)),
  );
});
