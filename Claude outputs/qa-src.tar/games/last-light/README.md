# Let There Be Light — Adventure 02

## Chapter openings and driving guidance

All five chapters begin with a clearly labeled dramatized call and a route-specific delivery objective. A skippable 22-second sequence moves from the existing clinician illustration to the clinic at dusk, cranes down from a wide dusk view of the compound (the doorway faintly lit by the reserve lamp), pushes through the front door and lands slowly at the bedside: a patient propped up on pillows, a clinician at the bedside with a chart, a companion in a chair and the warm, unsteady reserve lamp (eye-clinic chapters add an eye dressing). It then cuts to the chapter’s actual road, truck cargo and departure camera. People are the rigged staff model with trousers, shoes and poses (seated, propped up, leaning, looking) rather than the older primitive figures. These are illustrative people and fictional circumstances, separate from the documented project status. Existing voice recordings and their matching transcripts are preserved.

The route diagram samples the selected mission, including Fresh tracks and bypasses. Start delivery is available as soon as the scene loads, independent of narration or animation. Pause animation freezes the sequence; story audio has its own pause/replay control. Reduced motion keeps the clinician illustration still. Phone layouts show the scene above the story and put Start delivery and controls before the narration transcript. Real project statistics remain under About the real project.

Arrow keys are the primary instructions: hold ↑ to drive, ← / → to steer, and ↓ to slow/stop (continue holding after stopping to reverse). Remapped letters, touch and controllers remain available. The reserve starts only on acceleration. Every chapter supplies short movement prompts and a braking reminder for its first obstacle. Handover uses the visible Deliver kit button with the current shortcut.

The development-only `qa/clinic-story.html` fixture previews every chapter's opening, arrival and ending, has a shot selector for visual checks, accepts `?scene=opening|arrival|closing&id=0-4&t=seconds&paused=1` for repeatable frames, and supports muted, touch and reduced-motion modes without writing player saves. Graphics adjustments are queued before rendering and scale only the offscreen buffers, leaving the displayed canvas intact; actual canvas resizes redraw even while paused, and duplicate size notifications are ignored. The chase camera checks ground clearance after interpolation to prevent it entering rising banks. In the development-only `?qa=1` game, Stress graphics QA simulates slow frames to exercise adaptive resolution and tier changes without changing saved settings.

A standalone 3D driving game for the Global Solutions Lab games collection. Play as Amani, carrying solar panels and a charged battery to five clinics before their emergency reserve expires. Reach the courtyard, stop safely, hand over the kit, and watch the clinic become bright and active.

## Run

From the repository root, with Node 22.12 or later:

```sh
npm run setup:games
npm start
```

After pulling revision 7, run `npm install` in `games/last-light` once (it adds the streamed physics package `@dimforge/rapier3d`).

Open http://localhost:4200/games and choose Let There Be Light. `npm start` runs Angular and both isolated game servers. For Let There Be Light alone, run `npm run start:last-light` and visit http://127.0.0.1:5175/games/last-light/.

The combined development command uses Angular's `games` configuration to let requests reach the live game servers. `npm run start:app` retains the static, prebuilt game assets for an Angular-only preview.

```sh
npm run test:games
npm run build
npm run preview:site
```

The combined production build creates Angular and both game documents in `dist/`, then checks their entry assets, bundle isolation and compressed size budgets. Deployment uses the repository's existing Firebase workflow; this implementation does not deploy automatically.

## Play

- W / up: accelerate. S / down / space: brake; holding brake at a standstill reverses.
- A / D or left / right: steer. E: deliver in the marked courtyard or recover when stuck. Escape: pause.
- Stuck on a cliff or against traffic? Pause and choose **Recover truck · −8 seconds** to return to the last clear, firm checkpoint and continue the same delivery. This is always available while a drive is paused, even if automatic stuck detection has not triggered. The driving recovery prompt also detects blocked reverse attempts and stays available after releasing the pedals.
- Touch controls can be enabled in the driving HUD and appear automatically on touch-oriented devices. Hold DRIVE and a steering button together.
- Standard gamepads use the left stick, triggers, A / cross for the contextual action and the menu button to pause.
- Settings include remappable letter/number keys, volume, radio voice/subtitles, night brightness, enhanced night visibility, reduced lightning/camera motion, one-press delivery, graphics quality and Relaxed difficulty. Difficulty and graphics changes apply to the next drive.

### Journey soundtrack

“Morning on the Ridge” starts each drive as the main song. Near its end, a four-second equal-power crossfade brings in “Light at the Clearing”; the playlist then cycles back to Morning for longer drives and restoration/results scenes. Music fades in at a restrained level and lowers under spoken radio so road cues remain audible. There are no forced song changes during a hazard or handover.

The original user-supplied MP3s stream through two native audio elements and the existing Web Audio mix, without full-song decoding or blocking game startup. Start/Resume/Enable sound prime playback from a user gesture. The existing Sound & music toggle and Volume control apply to both music and effects. Pause, lost focus, hidden tabs, mute and zero volume preserve song positions; returning to chapters or restarting releases the streams. If one track fails, the other continues; if both fail, the original generated score remains available. Browser audio restrictions never prevent driving.

The total downloadable asset budget is now 21 MiB to include the two original MP3s; the compressed code budget is unchanged. This is a package size limit, not a startup download requirement. Hosting verification checks that both songs are packaged. Real-device Safari/iOS/Android audio checks remain recommended; desktop playback and mocked browser-policy tests cannot establish behavior on every physical device.

Every chapter now begins in golden light and ends at dusk: the sun is driven by route progress, so it sets as the clinic comes into view (savanna sunset, storm light, river dusk, highland nightfall, storm sunset). A scattering sky with moving clouds, sun-tinted height fog, layered mountain ranges, valley lakes and mist decks give each drive a horizon. Headlights, traffic lamps and fireflies take over as the light goes; the night profiles still govern the final stretch of every chapter. Automatic headlights follow steering and cast a bounded shadow once it is dark. Firm-road propulsion targets 80 km/h, with automatic gearing, progressive steering, per-wheel traction and speed-sensitive framing. Left/right input follows the driver's viewpoint consistently across keyboard, touch and controller adapters.

The centre of the road is no longer a universally safe line. Physical washouts require a marked firm strip or a bypass; moving minibuses indicate and pull into a stop, yielding to occupied space; single-lane bridge traffic must clear before crossing; announced trees fall into the road; deep floodwater slows progress more than the marked shallow route. Explicit branches share their geometry with vehicle collision and scoring. Incidental rocks and ruts stay out of the authored approach corridors. A clean pass requires the correct line, controlled speed where appropriate, traffic clearance, and no damage or recovery. Hard collisions, including fast CCD contacts, landings and severe suspension compression can damage cargo. Recovery costs eight seconds. From the second chapter on, climbs lead into genuine switchbacks along an exposed cliff (the highlands have two); leaving the edge causes a physical fall, then recovery to the last firm checkpoint. Reflectors, chevrons and a 25 km/h approach sign mark each hairpin. A lantern-led goat crossing reacts to approaching speed, and compact oncoming traffic gives room. Runoff rises before commitment and affects tire drag. Village compounds include homes, porches, corrugated roofs, pumps, footpaths, warm windows and residents walking between tasks.

Revision 5 adds a persistent roster of ten road vehicles in the first chapter and twelve in later chapters. Compact cars and loaded pickups travel in both directions, keep right, follow other vehicles and yield before the exposed hill and livestock crossings. They use firm bypasses around damaged sections and rejoin the shared road. Catch slower traffic, wait for a gap, and pass with room to spare. Minibuses signal, stop and depart once there is room; brake lamps, rotating wheels, ground-aligned bodies, surface spray and positional motor audio make their motion readable. Physical traffic contacts can damage the kit, and a struck driver waits until the truck has room to back away. Safe following can earn a clean traffic encounter too.

### Five places

Revision 6 gives every chapter its own road and a signature moment, so no two drives share a layout. Each chapter's shape, width, hills, overall climb, switchbacks, cliff depth and far vistas live with its mission data; hazards are authored per chapter with quiet stretches between them rather than a fixed rhythm.

- **The First Light, open savanna valley.** A wide road sweeps down into the valley with long views. Market day fills the village: wax-print awnings, parasols, vendors and people crossing between the stalls. People cross only while the market is calm; a hurrying truck makes them wait at the verge, and a clean pass means walking pace (under 18 km/h). Goats cross at dusk.
- **Before the Rain, rain forest.** A narrow, winding road under the trees, and the rain arrives during the drive: grip, spray, wipers, rain sound and headlight mode follow the weather where the truck is. A tree falls across the road, then an overloaded lorry sits bogged in the mud of the short route with its crew digging. Crawl past on the firm side or take the left detour. A forest switchback and a flooded crossing follow.
- **Across the River, river country.** The road follows a river that runs in its own channel, passes under the bridge and bends away before the climb out of the valley. A creek crosses the road on two timber runners: line up and crawl over, or take the detour. Off the runners, a wheel drops into the creek. Then the minibus stop, the damaged single-lane bridge and the climb.
- **Night Watch, highland escarpment.** A steady climb through twin switchbacks with deep drops. At night, leafy branches laid on the road mark a broken-down truck with its bonnet up and hazards flashing; the driver waits by the verge with a lantern. The exposed descent follows.
- **The Last Connection, storm country.** The storm thickens as you drive. A fresh landslide buries half the road in earth, rock and an uprooted tree; crawl through the marked passage. Then the switchback, bridge, flood, herd and falling tree, one last time.

Fresh tracks puts the damage on the other side of the road for washouts, floods, fallen trees, lorries, breakdowns, landslides and herds. Routine traffic shares the same rules: it slows through the market, goes single file right beside a blocker, and takes the signed bypasses.

Foreground frame delays no longer open an unexpected pause screen. Physics catch-up is bounded to six fixed steps; discarded wall time does not drain the reserve. Livestock braking assistance now builds progressively and releases when the truck's path clears. Lost focus, hidden tabs and deliberate pause still protect the delivery. Standard chapter reserves are 235/255/270/285/300 seconds, allowing careful driving and legitimate waits.

Pause or failure screens offer checkpoint practice. Practice uses a refreshed reserve and kit, and is explicitly excluded from records and unlocks. Scored recovery retains its time penalty. Revision 6 scores stay separate from previous road revisions (including revision 5) while preserving campaign completion.

Each clinic has its own compound, including recessed windows, wings, shelters, drainage and electrical equipment. The clock stops at accepted handover. The arrival is a 32-second letterboxed cinematic (`src/arrival.ts` holds the shared timeline; Skip, Enter or Escape jump to the end from the first frame):

1. **Arrival** — the team walks out to the truck.
2. **The handover** — the tailgate opens and two staff carry the kit around the truck to the power cabinet, hands on the frame.
3. **Connected** — the battery is set down and connected; the inverter lamp goes from red to amber to green and the charge display wakes.
4. **The panels** — a labelled time-lapse of the roof array going up panel by panel (a real installation takes a trained team several days).
5. **First light** — inside the same care room from the opening: the ceiling tube flickers on, the monitor and vaccine fridge wake, and everyone looks up.
6. **A brighter night, then why it matters** — the camera backs out through the door and across the porch, then a long low arc reveals the whole lit compound against the dusk sky; once outside, the chapter’s real-world fact appears with its source.

Lighting is metered like a film: interiors lower exposure and bloom once the ceiling light is on, the lit compound is held slightly under at night, the parked truck drops to parking lamps and the porch lights are soft so the warm windows read without blowing out.

Reduced motion replaces the camera moves with three still frames. A charged battery supplies immediate power at night; the installed roof array stays in the completed-clinic view.

### Real-world facts

Each chapter ends with one sourced fact (WHO, World Bank, IRENA & SEforALL, *Energizing Health*, 2023), in `content/drc-clinic-stories.json` beside the clinic it belongs to: 25,000+ facilities without power, only about half with reliable power, nearly a billion people affected, what electricity powers beyond lights, and solar with batteries not waiting for the grid. The fact also appears on the completion screen with its source and a link to help the real team; the final chapter spells out the call to help. Facts are kept visually separate from the fictional story.

| Chapter | Landscape | Signature moment | Also on the road |
| --- | --- | --- | --- |
| The First Light | Open savanna valley | Market day in the village | Washout, goats at dusk |
| Before the Rain | Rain forest | Rain arrives; a lorry bogged in the mud | Falling tree, switchback, flood |
| Across the River | River country | Timber plank crossing over a creek | Minibus stop, single-lane bridge, switchback, oncoming vehicle |
| Night Watch | Highland escarpment | Twin switchbacks; a breakdown marked with branches | Washout, exposed descent |
| The Last Connection | Storm country | A fresh landslide | Switchback, bridge, flood, herd, falling tree |

On-time delivery earns 1,000 points plus up to 400 for reserve remaining, 400 for cargo condition, and 200 for clean encounters. A clean encounter is credited once; revisiting cannot multiply the award. Valley run and Fresh tracks use deterministic different hazard layouts. Stars reward a stronger delivery. Clinic completion unlocks the next chapter; new best scores are stored separately by Standard/Relaxed, road edition, and rules revision. Existing records remain in storage under their legacy keys and existing clinic unlocks carry over. Lives saved are authored fictional story outcomes, counted once per clinic, not multiplied by replaying. Progress and preferences are local to this browser and origin under `last-light.v1`.

### Plays everywhere (revision 7)

Revision 7 makes the game load quickly on slow and metered connections and run smoothly on older phones. On capable devices, High looks the same as before.

- **Smaller first drive.** From opening the page to the first drive, the game now downloads about 1.7 MB (menu art, code, physics, surfaces and characters), down from about 11 MB. Clinic compounds are built from code rather than downloaded. The staff model is meshopt-compressed. Textures and key art are WebP. The physics engine streams and compiles its WebAssembly while it downloads. A few seconds on the menu prefetch the drive's code and surfaces, unless data saver is on.
- **Connection-aware extras.** Music streams 96 kbps copies unless the connection is fast and unmetered. Sharper road and ground textures arrive a few seconds into the drive, and only on fast connections; the base set is always complete.
- **Offline repeat visits.** A small service worker caches the game's files after the first visit. Its cache name is a hash of the build, so every deploy is picked up; audio range requests go straight to the network.
- **Graphics tiers.** Settings offer Auto, High, Balanced and Light. Auto starts from the GPU, memory, cores and input type. High keeps MSAA, sun shafts, bloom and terrain and headlight shadows. Balanced uses FXAA and drops the two costliest shadows while keeping the golden-hour shafts and bloom. Light targets older phones: it drops post effects and renders less vegetation. On Auto, a frame governor first lowers resolution (down to 60 %) when frames run long, then steps down one tier; it never steps up mid-drive, so the look does not flicker.
- **No hitches.** Shaders are compiled before the drive starts, against the same render target they draw to ("Lighting the road"). Vehicle beams share one pooled spotlight, so the light count never changes. Each person is one draw call. Road geometry lookups are cached per station.

## Structure

- `src/engine.ts`: fixed 60 Hz Rapier simulation, raycast vehicle suspension, collisions, traction, cargo, clock and mission state machine.
- `src/missions.ts`, `road-sections.ts`, `vehicle.ts`, `encounters.ts`: five chapters (each with its own road shape, relief, weather, river, switchbacks and authored moments), deterministic road editions, shared road/collision surfaces, safe corridors, handling profiles and moving encounter trajectories.
- `src/set-pieces.ts`, `set-piece-art.ts`: deterministic placement shared by physics and art for the market stalls and crossing villagers, landslide rocks, plank runners and parked vehicles, and their art: stalls, crowds, the bogged lorry and its crew, the creek, the broken-down truck with warning branches and the landslide.
- `src/world.ts`, `art.ts`, `foliage.ts`, `surfaces.ts`, `living-world.ts`: Three.js renderer, chunked terrain, shaped truck meshes, skinned characters, wind animation, roadside villages, sky-baked image lighting, rain, surface spray, headlights, clinic interiors, unloading and camera choreography.
- `src/atmosphere.ts`, `post.ts`, `camera-rig.ts`: golden-hour → dusk sky and lighting, height fog with aerial perspective, post-processing (sun shafts, bloom, filmic grade, SMAA/FXAA by quality) and the spring-damped chase camera with its opening crane shot.
- `src/biome.ts`, `landscape.ts`, `scenery-layout.ts`: procedural African vegetation (acacia, baobab, oil palm, banana, euphorbia, broadleaf, elephant grass, termite mounds, granite kopjes), ridgelines, valley water, mist, birds, fireflies and village smoke. The layout is deterministic and shared with physics, so trees, boulders, homes and bridge rails are solid (one merged static collider) and reflector posts and signs are knocked over by the truck.
- `src/routes.ts`, `route-art.ts`: invertible route coordinates, the real switchback, width compensation, cliff terrain, arc distance, and consistent static geometry placement.
- `src/traffic-flow.ts`, `traffic-art.ts`, `frame-health.ts`: persistent traffic, physical-distance lanes, pooled car art/lights/audio coordination, collision clearance and raw frame diagnostics.
- `src/traffic.ts`, `herd-art.ts`, `village.ts`: reactive vehicle movement, herd timing and animation, shared village architecture and daily activity.
- `src/App.tsx`, `input.ts`, `audio.ts`, `journey-music.ts`, `save.ts`: interface, input adapters, recorded engine, streamed music and generated soundscape, optional browser speech and resilient local saves.
- `src/night.ts`, `road-art.ts`, `clinic-assets.ts`, `clinic-architecture.ts`, `staff.ts`: night profiles, hazard markers/water, chapter-specific clinic compounds and animated staff.
- `src/quality.ts`, `network.ts`, `vendor/`, `scripts/offline-cache.ts`: graphics tiers and the frame governor, connection-aware downloads, the streamed Rapier loader and the offline cache. Reproducible asset preparation scripts live in `scripts/`; provenance is in `ASSETS.md`.

Game libraries are independent of the Angular application and Lost in Orbit. Heavy rendering and physics modules load when a drive starts. Texture fallbacks keep a missing material download from preventing play. Rendering supports tiered quality with automatic resolution and tier adjustment, reduced camera motion and a restart path for WebGL context loss. Timers pause on lost focus or page visibility, and long frame gaps do not consume the mission clock.

## Completion screen

The completed clinic stays visible above a compact action panel with the real team photo, drive summary, sharing, leaderboard and next clinic. After a guest's first delivery, account creation, login and replay are visible in the primary actions. Members continue directly; unverified members can play with a leaderboard verification reminder. Full statistics and additional account controls open in Drive details. Sharing works for guests, and practice shares omit a recorded score. Narration uses the existing audio controls and transcript preference; the full transcript remains available when audio is muted or unavailable. Small screens can scroll the panel, and dialogs support Escape and return focus to their trigger. The final chapter returns to the map; practice starts a full delivery of the same chapter.

### First-delivery guest access

Guests can retry and replay the first clinic. The other four clinics require a free account, using the game's four-field signup or existing-account login. Progress transfers without discarding a better score or replacing an existing unfinished account journey without a choice. Invite 10 friends and Contribute $10 remain available to guests and members, independently of signup. See [account conversion verification](../../docs/design/last-light/account-conversion-verification.md) for the behavior and checks. Run `npm run test:last-light-auth` from the repository root for the focused signup and return-flow tests.

## Verification

See [soundtrack verification](../../docs/design/last-light/soundtrack-verification.md) for music playback, lifecycle, packaging checks and device-testing limits. The development-only `/games/last-light/qa/music.html` diagnostic exercises real native playback and both crossfade boundaries without changing game saves.

The regression suite checks complete ordinary-input deliveries on both routes; deadline ordering, pause, recovery, damage, delivery cancellation, frozen rewards, storage and keyboard/touch/controller adapters. Upgrade coverage adds faster deliveries in both road editions and on both routes, acceleration/braking, mud transitions, physical ruts, a real vehicle collision, deterministic encounters, duplicate-award prevention and legacy-record preservation. The existing Lost in Orbit suite is retained.

The development-only `?qa=1` control drives the actual vehicle through the ordinary input API at a faster pace, slowing for mud, bridges and the delivery bay. It does not teleport, bypass deadlines or manufacture successful deliveries. Production verification rejects the QA interface in built JavaScript. Frame diagnostics report actual frame intervals before simulation clamping, including p50/p95/p99, lifetime maximum and long-frame counts. Pause reason, discarded simulation time and physics/render CPU averages are also visible; slow frames are retained.

Graphics combine original authored geometry, CC0 rigged Quaternius staff and locally bundled photographic materials, with lighting baked from the game's sky. Menu/concept artwork is separately generated art, not a gameplay screenshot. Desktop checks use a 1280×720 viewport; performance must also be measured on target devices. Responsive layout checks do not substitute for physical iOS/Android/controller tests, and automated completion does not establish player enjoyment or retention. The game narrative is English; the catalog includes English and French copy.

See [optimisation verification](../../docs/design/last-light/optimization-verification.md), [five places verification](../../docs/design/last-light/five-places-verification.md), [traffic and smoothness verification](../../docs/design/last-light/traffic-flow-verification.md), [living-roads verification](../../docs/design/last-light/living-roads-verification.md), [night-journey verification](../../docs/design/last-light/night-journey-verification.md), [previous upgrade verification](../../docs/design/last-light/upgrade-verification.md), [asset provenance](ASSETS.md) and the [original design package](../../docs/design/last-light/README.md).
