// Development-only scene/asset fixture. Vite's production entry never imports this file.
// Real rendering and audio controllers; isolated settings and no storage writes.
import { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ClinicStoryView } from '../src/ClinicStory';
import { CLINICS, storyClip, type StoryScene } from '../src/clinic-stories';
import { defaultSettings } from '../src/save';
import { GameEngine, initPhysics } from '../src/engine';
import { MISSIONS, roadY } from '../src/missions';
import { GameWorld } from '../src/world';
import { loadSurfaces } from '../src/surfaces';
import { loadStaff } from '../src/staff';
import { loadClinic } from '../src/clinic-assets';
import { Soundtrack } from '../src/audio';
import { OPENING_DURATION } from '../src/OpeningBriefing';
import { ArrivalOverlay } from '../src/ArrivalOverlay';
import { ARRIVAL } from '../src/arrival';
import { RESTORE_DURATION } from '../src/vehicle';

type QAScene = StoryScene | 'arrival';
// ?scene=opening|arrival|closing&id=0..4&t=seconds&paused=1&still=1 opens a shot directly.
const query = new URLSearchParams(location.search);
// &account=guest|unverified|verified previews account CTAs without authentication.
// &cam=ex,ey,ez,ax,ay,az frames a clinic-local viewpoint (development only).
if (query.get('cam')) { const v = query.get('cam')!.split(',').map(Number); (window as any).__llCam = { eye: v.slice(0, 3), aim: v.slice(3, 6) }; }
import '../src/style.css';

function StoryQA() {
  const [id, setId] = useState(Number(query.get('id') || 0)), [scene, setScene] = useState<QAScene | null>((query.get('scene') as QAScene) || null), [ready, setReady] = useState(false), [, tick] = useState(0), [report, setReport] = useState('Not checked');
  const canvas = useRef<HTMLCanvasElement>(null), sound = useRef<Soundtrack | null>(null);
  const settings = useRef(defaultSettings());
  const previewTime = useRef(Number(query.get('t') || 0)), previewPaused = useRef(query.get('paused') === '1');
  if (query.get('still') === '1') settings.current.reducedMotion = true;
  const engineRef = useRef<GameEngine | null>(null);
  const [touch, setTouch] = useState(false);
  useEffect(() => {
    if (!scene || !canvas.current) return;
    let cancelled = false, raf = 0, engine: GameEngine | undefined, world: GameWorld | undefined;
    setReady(false);
    void (async () => {
      await Promise.all([initPhysics(), loadSurfaces(), loadStaff(), loadClinic(id)]);
      if (cancelled) return;
      engine = new GameEngine(MISSIONS[id]);
      if (scene !== 'opening') {
        const position = { x: 0, y: roadY(engine.mission, engine.mission.length) + 1, z: engine.mission.length - 2 };
        engine.body.setTranslation(position, true);
        engine.position = { ...position };
        engine.previousPosition = { ...position };
        engine.progress = position.z;
        engine.roadPosition = { x: 0, z: position.z };
      }
      engine.phase = scene === 'closing' ? 'results' : scene === 'arrival' ? 'restoring' : 'ready';
      engine.restoreTime = scene === 'arrival' ? previewTime.current : RESTORE_DURATION;
      engineRef.current = engine;
      world = new GameWorld(canvas.current!, engine, settings.current);
      await world.prepare();
      if (cancelled) return;
      setReady(true);
      let last = performance.now(), renderedPreview = -1;
      const frame = (now: number) => {
        if (cancelled || !world || !engine) return;
        const dt = Math.min(.06, (now - last) / 1000); last = now;
        if (scene === 'arrival') {
          if (!previewPaused.current && engine.phase === 'restoring') previewTime.current = Math.min(ARRIVAL.end, previewTime.current + dt);
          engine.restoreTime = previewTime.current;
          if (engine.restoreTime >= ARRIVAL.end) engine.phase = 'results';
        }
        if (scene === 'opening' && !settings.current.reducedMotion) {
          if (!previewPaused.current && !document.hidden) previewTime.current = Math.min(OPENING_DURATION, previewTime.current + dt);
          world.openingTime = previewTime.current;
        }
        if (!previewPaused.current || previewTime.current !== renderedPreview) {
          world.render(previewPaused.current ? 0 : dt, dt);
          renderedPreview = previewTime.current;
        }
        if (scene === 'opening') sound.current?.updateStory(dt);
        else sound.current?.update(engine, dt);
        tick(n => n + 1);
        raf = requestAnimationFrame(frame);
      };
      raf = requestAnimationFrame(frame);
    })();
    return () => { cancelled = true; cancelAnimationFrame(raf); world?.dispose(); engine?.dispose(); };
  }, [scene, id]);
  const show = (next: QAScene) => {
    previewTime.current = 0; previewPaused.current = false;
    sound.current?.dispose();
    sound.current = new Soundtrack(settings.current, CLINICS[id]);
    sound.current.setStory(next === 'arrival' ? null : next);
    void sound.current.unlock();
    if (next !== 'opening') sound.current.arrival();
    setScene(next);
  };
  const home = () => { sound.current?.dispose(); sound.current = null; setScene(null); };
  const validate = async () => {
    const context = new AudioContext();
    const rows: string[] = [];
    try {
      for (const clinic of CLINICS) for (const scene of ['opening', 'closing'] as const) {
        const response = await fetch(storyClip(clinic, scene));
        if (!response.ok) throw new Error(`${clinic.id}/${scene}: HTTP ${response.status}`);
        const bytes = await response.arrayBuffer();
        const byteLength = bytes.byteLength;
        const decoded = await context.decodeAudioData(bytes);
        let peak = 0, sum = 0;
        const channel = decoded.getChannelData(0);
        for (const sample of channel) { peak = Math.max(peak, Math.abs(sample)); sum += sample * sample; }
        if (decoded.duration < 5 || peak < .01) throw new Error(`${clinic.id}/${scene}: silent or incomplete`);
        rows.push(`${clinic.id} ${scene}: ${decoded.duration.toFixed(2)}s, peak ${peak.toFixed(3)}, RMS ${Math.sqrt(sum / channel.length).toFixed(3)}, ${(byteLength / 1024).toFixed(0)} KiB`);
        setReport(rows.join('\n'));
      }
      setReport(`PASS — all ten MP3s fetched, decoded and contain audio.\n${rows.join('\n')}`);
    } catch (error) { setReport(`FAIL — ${error}\n${rows.join('\n')}`); }
    finally { await context.close(); }
  };
  return scene ? <main className="last-light in-game">
    {scene === 'opening' && <div style={{position:'fixed',bottom:4,right:8,zIndex:30,background:'#132d30',padding:6,fontSize:11}}>
      <label>Preview shot <select aria-label="Preview shot" value={previewPaused.current ? String(previewTime.current) : 'auto'} onChange={event => {
        previewPaused.current = event.target.value !== 'auto';
        if (previewPaused.current) previewTime.current = Number(event.target.value);
        tick(n => n + 1);
      }}><option value="auto">Play sequence</option><option value="0">The call</option><option value="4">The door</option><option value="8">The care room</option><option value="11">The road</option><option value="15">The kit</option><option value="19">Your turn</option></select></label>
    </div>}
    <canvas ref={canvas} className="game-canvas" />{scene === 'arrival' && ready ? (engineRef.current?.phase === 'restoring' ? <ArrivalOverlay time={previewTime.current} clinic={CLINICS[id]} still={settings.current.reducedMotion} onSkip={() => { previewTime.current = ARRIVAL.end; }} /> : null) : <ClinicStoryView clinic={CLINICS[id]} chapter={id} scene={scene === 'arrival' ? 'closing' : scene} settings={settings.current} narration={sound.current?.narration || {scene:null,status:'idle',progress:0}} onVoice={() => {sound.current?.toggleNarration();void sound.current?.unlock();}} onHome={home} onSettings={home} onContinue={home} onReplay={home} touch={touch} onTouch={() => setTouch(v => !v)} ready={ready} loading="Preparing preview" previewTime={previewTime.current} previewPaused={previewPaused.current} onPreviewPause={() => {previewPaused.current = !previewPaused.current; tick(n => n + 1);}} accountStatus={query.get('account') === 'guest' ? 'guest' : ['unverified','verified'].includes(query.get('account') || '') ? 'signed-in' : undefined} emailVerified={query.get('account') === 'verified'} onGuestReplay={home} onAuth={home} completed={Array.from({length:id+1},(_,i)=>i)} result={scene!=='opening' ? {mission:id,mode:'standard',score:1752,stars:3,integrity:100,remaining:74,lives:MISSIONS[id].lives,clean:9,encounters:10} : undefined} />}</main> : <main style={{padding:30}}><h1>Story verification</h1><p>Development fixture · no saves written. Preview the real scene components and decode every local recording.</p><label>Clinic <select value={id} onChange={e=>setId(Number(e.target.value))}>{CLINICS.map((c,i)=><option key={c.id} value={i}>{c.name}</option>)}</select></label><p><label><input type="checkbox" checked={settings.current.reducedMotion} onChange={e => {settings.current.reducedMotion = e.target.checked; tick(n => n + 1);}} /> Reduced motion</label> <label><input type="checkbox" checked={!settings.current.sound} onChange={e => {settings.current.sound = !e.target.checked; tick(n => n + 1);}} /> Sound off</label> <label><input type="checkbox" checked={touch} onChange={e => setTouch(e.target.checked)} /> Touch controls</label></p><p><button onClick={()=>show('opening')}>Preview opening</button> <button onClick={()=>show('arrival')}>Preview arrival</button> <button onClick={()=>show('closing')}>Preview ending</button> <button onClick={()=>void validate()}>Validate all voice files</button></p><pre style={{whiteSpace:'pre-wrap'}}>{report}</pre></main>;
}
createRoot(document.getElementById('root')!).render(<StoryQA />);
