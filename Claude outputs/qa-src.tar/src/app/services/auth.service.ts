import { getLanguage } from '../../../content/last-light-locale';
import { captureAuthReturn, gameAuthReturn, navigateAuthReturn, safeAuthReturn } from './auth-return';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFireFunctions } from '@angular/fire/compat/functions';
import {
  AngularFirestore,
  AngularFirestoreCollection,
  AngularFirestoreDocument,
  DocumentReference,
} from '@angular/fire/compat/firestore';
import { Router } from '@angular/router';
import {
  Observable,
  combineLatest,
  firstValueFrom,
  map,
  of,
  shareReplay,
  switchMap,
  take,
  tap,
} from 'rxjs';
import { NewUser, PlanKey, PRICE_BOOK, School, User } from '../models/user';
import { TimeService } from './time.service';
import { DemoBooking, GslPrepEmailTemplate } from '../models/tournament';
import { serverTimestamp } from 'firebase/firestore';
import firebase from 'firebase/compat/app';
import { PresenceService } from './presence.service';
// Add this where you keep shared types (optional)

interface RegisterSchoolMeta {
  plan: PlanKey;
  currency: string; // e.g., 'USD'
  extraTeams: number; // integer
  schoolCountry?: string;
  schoolType?: string; // 'Public' | 'Private' | 'IB' | 'Other'
  schoolWebsite?: string;
  courseType?: string;
  coursePurpose?: string;
  specificFocus?: string;
}

export type RegistrationOutcome =
  | { status: 'created'; profileRepaired: true; verificationSent?: boolean }
  | { status: 'recovered-unverified'; profileRepaired: boolean; verificationSent?: boolean }
  | { status: 'recovered-verified'; profileRepaired: boolean; verificationSent?: boolean };

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user$: Observable<any>;
  email?: Observable<any>;
  currentUser: any = {};
  currentAuthUid: string | null = null;
  newUser: NewUser = {};
  logingError?: Observable<any>;
  private redirectUrl: string = '';
  private activeUid: string | null = null;
  private lastActiveWriteAtMs = 0;
  private activityTrackingBound = false;
  private readonly minLastActiveWriteIntervalMs = 5 * 60 * 1000;
  private readonly gslPrepEmailTemplateDoc =
    'admin_settings/gsl2026_prep_email_template';

  constructor(
    private fireauth: AngularFireAuth,
    private afs: AngularFirestore,
    private fns: AngularFireFunctions,
    private router: Router,
    private time: TimeService,
    private presence: PresenceService
  ) {
    this.newUser = {
      firstName: '',
      lastname: '',
      password: '',
      goal: '',
      sdgsSelected: [],
    };
    this.user$ = this.fireauth.authState.pipe(
      switchMap((user) => {
        if (user) {
          this.email = of(user.email);
          return this.afs.doc<User>(`users/${user.uid}`).valueChanges().pipe(
            map((profile) => ({
              ...(profile || {}),
              uid: profile?.uid || user.uid,
              email: profile?.email || user.email || '',
              emailLower:
                profile?.emailLower || (profile?.email || user.email || '').toLowerCase(),
            }))
          );
        } else {
          return of(null);
        }
      }),
      tap((user) => {
        this.currentUser = user;
      }),
      shareReplay({ bufferSize: 1, refCount: true })
    );
    this.initLastActiveTracking();
    this.getCurrentUser();
  }
  setRedirectUrl(url: string) {
    this.redirectUrl = url;
  }
  getRedirectUrl(): string {
    return this.redirectUrl;
  }

  async getCurrentUserPromise() {
    const user = await firstValueFrom(this.user$.pipe(take(1)));
    this.currentUser = user;
    return user;
  }

  updateStatusOnline(userId: string) {
    console.log('Updating status online for userId:', userId);
    const userRef: AngularFirestoreDocument<User> = this.afs.doc(
      `users/${userId}`
    );
    const data = {
      status: 'online',
    };
    userRef.set(data, { merge: true });
  }
  updateStatusOffline() {
    console.log(
      'Updating status offline for currentUser UID:',
      this.currentUser?.uid
    );
    const userRef: AngularFirestoreDocument<User> = this.afs.doc(
      `users/${this.currentUser.uid}`
    );
    const data = {
      status: 'offline',
    };
    userRef.set(data, { merge: true });
  }
  getCurrentUser() {
    this.user$.subscribe((user) => {
      this.currentUser = user;
    });
  }

  getObservableUser() {
    return this.user$;
  }
  async register(
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    goal: string,
    sdgsSelected: string[],
    options: { continueGame?: boolean } = {}
  ): Promise<RegistrationOutcome> {
    const continueGame = options.continueGame === true && !!gameAuthReturn();
    // `undefined` means registration is still in progress. Setting this to
    // false here made the UI briefly show a failure before the async work
    // completed successfully.
    this.newUser.success = undefined;
    this.newUser.errorMessage = '';

    try {
      let credential: firebase.auth.UserCredential;
      try {
        credential = await this.fireauth.createUserWithEmailAndPassword(
          email.trim(),
          password
        );
      } catch (error: any) {
        if (error?.code === 'auth/email-already-in-use') {
          const outcome = await this.recoverExistingRegistration(
            firstName,
            lastName,
            email,
            password,
            goal,
            sdgsSelected,
            continueGame
          );
          this.newUser.success = true;
          return outcome;
        }
        throw error;
      }
      if (!credential.user) {
        throw new Error('Firebase did not return the newly created account.');
      }

      // Create the profile before sending the user away. Awaiting this write is
      // important: the previous fire-and-forget flow reported success even when
      // Firestore rejected the profile document.
      await this.registrationProfile(this.addNewUser(
        firstName.trim(),
        lastName.trim(),
        credential.user,
        goal,
        sdgsSelected
      ), continueGame);
      const verificationSent = await this.registrationVerification(credential.user, continueGame);
      this.newUser.success = true;
      return { status: 'created', profileRepaired: true, verificationSent };
    } catch (error: any) {
      this.newUser.success = false;
      this.newUser.errorMessage =
        error?.message || 'Unable to create your account. Please try again.';
      throw error;
    }
  }

  private async recoverExistingRegistration(
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    goal: string,
    sdgsSelected: string[],
    continueGame = false
  ): Promise<RegistrationOutcome> {
    let credential: firebase.auth.UserCredential;
    try {
      // The password proves ownership before any profile is repaired. This
      // also prevents the Get Started form from exposing another account.
      credential = await this.fireauth.signInWithEmailAndPassword(
        email.trim(),
        password
      );
    } catch (error: any) {
      const ownershipError: any = new Error(
        'Your account already exists. Go to login with your existing password, use password reset, or choose the social sign-in method you originally used.'
      );
      ownershipError.code = 'auth/existing-account-sign-in-required';
      ownershipError.cause = error;
      throw ownershipError;
    }

    const user = credential.user;
    if (!user) {
      throw new Error('Unable to open the existing account for recovery.');
    }

    await user.reload();
    const profileRepaired = await this.registrationProfile(this.repairRegistrationProfile(
      user,
      firstName,
      lastName,
      goal,
      sdgsSelected
    ), continueGame);

    if (user.emailVerified) {
      try { await this.markUserVerified(user.uid); }
      catch (error) { if (!continueGame) throw error; }
      // Send the user through a deliberate login after recovery so they start
      // with a fresh token and a predictable post-repair session.
      if (!continueGame) await this.fireauth.signOut();
      return { status: 'recovered-verified', profileRepaired };
    }

    const verificationSent = await this.registrationVerification(user, continueGame, true);
    return { status: 'recovered-unverified', profileRepaired, verificationSent };
  }

  private async registrationVerification(user: firebase.User, continueGame: boolean, recovering = false): Promise<boolean> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const sending = this.sendEmailForVerification(user);
      // Email delivery must not hold a successfully created game account hostage.
      if (continueGame) await Promise.race([sending, new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error('Verification email is taking longer than expected.')), 10000);
      })]);
      else await sending;
      return true;
    } catch (error: any) {
      if (!continueGame && !(recovering && error?.code === 'functions/resource-exhausted')) throw error;
      return false;
    } finally { if (timer) clearTimeout(timer); }
  }

  private async registrationProfile<T>(writing: Promise<T>, continueGame: boolean): Promise<T> {
    if (!continueGame) return writing;
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([writing, new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(Object.assign(new Error('Your account profile is still syncing.'), { code: 'auth/game-profile-pending' })), 18000);
      })]);
    } finally { if (timer) clearTimeout(timer); }
  }

  private async repairRegistrationProfile(
    user: firebase.User,
    firstName: string,
    lastName: string,
    goal: string,
    sdgsSelected: string[]
  ): Promise<boolean> {
    const userRef = this.afs.doc<User>(`users/${user.uid}`);
    const snapshot = await userRef.ref.get();

    if (!snapshot.exists) {
      await this.addNewUser(
        firstName.trim(),
        lastName.trim(),
        user,
        goal,
        sdgsSelected
      );
      return true;
    }

    const current = snapshot.data() as User;
    const updates: Record<string, unknown> = {};
    const submittedFirstName = firstName.trim();
    const submittedLastName = lastName.trim();
    const emailLocalPart = (user.email || '').split('@')[0] || '';
    const normalizeNameToken = (value: string) =>
      value.toLowerCase().replace(/[^a-z0-9]/g, '');
    const currentFirstName = (current?.firstName || '').trim();
    const currentFirstWasDerivedFromEmail =
      !!currentFirstName &&
      !!emailLocalPart &&
      normalizeNameToken(currentFirstName) === normalizeNameToken(emailLocalPart);
    const setIfMissing = (key: string, value: unknown) => {
      const existing = (current as any)?.[key];
      if (
        existing === undefined ||
        existing === null ||
        (typeof existing === 'string' && existing.trim() === '')
      ) {
        updates[key] = value;
      }
    };

    setIfMissing('uid', user.uid);
    setIfMissing('email', user.email || '');
    setIfMissing('emailLower', (user.email || '').toLowerCase());
    if (
      currentFirstWasDerivedFromEmail &&
      submittedFirstName &&
      normalizeNameToken(currentFirstName) !==
        normalizeNameToken(submittedFirstName)
    ) {
      // Older repair logic used the email's local part as a placeholder name.
      // An explicitly submitted name from an authenticated owner is the more
      // reliable value and should replace that placeholder.
      updates['firstName'] = submittedFirstName;
      updates['firstNameLower'] = submittedFirstName.toLowerCase();
      if (submittedLastName) {
        updates['lastName'] = submittedLastName;
        updates['lastNameLower'] = submittedLastName.toLowerCase();
      }
    } else {
      setIfMissing('firstName', submittedFirstName);
      setIfMissing('firstNameLower', submittedFirstName.toLowerCase());
      setIfMissing('lastName', submittedLastName);
      setIfMissing('lastNameLower', submittedLastName.toLowerCase());
    }
    setIfMissing('goal', goal);
    if (!Array.isArray(current?.sdgsSelected) || !current.sdgsSelected.length) {
      updates['sdgsSelected'] = sdgsSelected;
    }
    setIfMissing('dateJoined', this.time.getCurrentDate());
    setIfMissing('followers', '0');
    setIfMissing('following', '0');
    setIfMissing('contentViews', '0');

    if (Object.keys(updates).length) {
      await userRef.set(updates as Partial<User>, { merge: true });
      return true;
    }
    return false;
  }

  async sendEmailForVerification(user: firebase.User | null): Promise<void> {
    if (!user) {
      throw new Error('No signed-in user is available for email verification.');
    }

    try {
      const sendVerification = this.fns.httpsCallable(
        'sendBrandedVerificationEmail'
      );
      const returnTo = gameAuthReturn();
      await firstValueFrom(sendVerification({ ...(returnTo ? { returnTo, origin: window.location.origin } : {}), language: getLanguage() }));
    } catch (error) {
      if ((error as any)?.code === 'functions/resource-exhausted') {
        throw error;
      }
      // Keep verification available while a new Functions deployment is
      // propagating, or if the email provider has a temporary outage.
      console.warn(
        'Branded verification email failed; using Firebase fallback.',
        error
      );
      (await this.fireauth.app).auth().languageCode = getLanguage();
      await user.sendEmailVerification({
        url: gameAuthReturn() && ['https://globalsolutionlab.com', 'https://www.globalsolutionlab.com', 'https://newworld-game.org', 'https://www.newworld-game.org'].includes(window.location.origin)
          ? `${window.location.origin}/verify-email?verified=1&lang=${getLanguage()}&redirectTo=${encodeURIComponent(gameAuthReturn()!)}`
          : 'https://newworld-game.org/verify-email?verified=1',
      });
    }
  }
  getAUser(uid: string) {
    return this.afs.doc<User>(`users/${uid}`).valueChanges();
  }
  getALlUsers() {
    return this.afs.collection<User>(`users`).valueChanges();
  }

  async getUsersByEmails(emails: string[]): Promise<User[]> {
    const normalizedEmails = Array.from(
      new Set(
        (emails || [])
          .map((email) => String(email || '').trim().toLowerCase())
          .filter(Boolean)
      )
    );
    if (!normalizedEmails.length) {
      return [];
    }

    const chunks: string[][] = [];
    for (let index = 0; index < normalizedEmails.length; index += 30) {
      chunks.push(normalizedEmails.slice(index, index + 30));
    }

    const snapshots = await Promise.all(
      chunks.flatMap((chunk) => [
        this.afs
          .collection<User>('users')
          .ref.where('emailLower', 'in', chunk)
          .get(),
        this.afs
          .collection<User>('users')
          .ref.where('email', 'in', chunk)
          .get(),
      ])
    );

    const usersById = new Map<string, User>();
    snapshots.forEach((snapshot) => {
      snapshot.docs.forEach((doc) => {
        const user = doc.data() as User;
        usersById.set(doc.id, {
          ...user,
          uid: user.uid || doc.id,
        });
      });
    });

    return Array.from(usersById.values());
  }

  /**
   * Search users by email prefix - scalable Firestore query
   * Uses Firestore's string ordering for efficient prefix matching
   */
  searchUsersByEmail(searchTerm: string, limitCount: number = 10) {
    const term = searchTerm.toLowerCase().trim();
    if (!term) {
      return new Observable<User[]>(observer => observer.next([]));
    }
    // Firestore prefix search: >= term and < term + high unicode char
    const endTerm = term + '\uf8ff';
    return this.afs
      .collection<User>(`users`, (ref) =>
        ref
          .where('email', '>=', term)
          .where('email', '<=', endTerm)
          .limit(limitCount)
      )
      .valueChanges();
  }

  /**
   * Search users by firstName prefix - scalable Firestore query
   */
  searchUsersByFirstName(searchTerm: string, limitCount: number = 10) {
    const term = searchTerm.toLowerCase().trim();
    if (!term) {
      return new Observable<User[]>(observer => observer.next([]));
    }
    const endTerm = term + '\uf8ff';
    return this.afs
      .collection<User>(`users`, (ref) =>
        ref
          .where('firstNameLower', '>=', term)
          .where('firstNameLower', '<=', endTerm)
          .limit(limitCount)
      )
      .valueChanges();
  }

  /**
   * Combined search - searches email and returns results
   * For full-text search across multiple fields, consider Algolia/Typesense at scale
   */
  searchUsers(searchTerm: string, limitCount: number = 15) {
    const term = searchTerm.toLowerCase().trim();
    if (!term) {
      return of([]);
    }

    const prefixTerm = term.split(/\s+/)[0];
    const variants = this.getUserSearchTermVariants(prefixTerm);
    const perFieldLimit = Math.min(Math.max(limitCount, 5), 10);

    const searches = [
      this.searchUsersByPrefixField('email', term, perFieldLimit),
      this.searchUsersByPrefixField('emailLower', term, perFieldLimit),
      this.searchUsersByPrefixField('firstNameLower', prefixTerm, perFieldLimit),
      this.searchUsersByPrefixField('lastNameLower', prefixTerm, perFieldLimit),
      ...variants.map((variant) =>
        this.searchUsersByPrefixField('firstName', variant, perFieldLimit)
      ),
      ...variants.map((variant) =>
        this.searchUsersByPrefixField('lastName', variant, perFieldLimit)
      ),
    ];

    return combineLatest(searches).pipe(
      map((groups) => {
        const unique = new Map<string, User>();

        for (const user of groups.flat()) {
          const haystack = [
            user.email || '',
            user.firstName || '',
            user.lastName || '',
            `${user.firstName || ''} ${user.lastName || ''}`,
            user.profileCredential || '',
            user.profileDescription || '',
          ]
            .join(' ')
            .toLowerCase();

          if (!haystack.includes(term)) continue;

          const key = user.uid || user.email || `${user.firstName}|${user.lastName}`;
          if (key && !unique.has(key)) {
            unique.set(key, user);
          }
        }

        return Array.from(unique.values()).slice(0, limitCount);
      })
    );
  }

  private searchUsersByPrefixField(
    field: string,
    term: string,
    limitCount: number
  ): Observable<User[]> {
    const normalized = term.trim();
    if (!normalized) return of([]);

    const endTerm = normalized + '\uf8ff';
    return this.afs
      .collection<User>(`users`, (ref) =>
        ref
          .where(field, '>=', normalized)
          .where(field, '<=', endTerm)
          .limit(limitCount)
      )
      .valueChanges();
  }

  private getUserSearchTermVariants(term: string): string[] {
    const trimmed = term.trim();
    const lower = trimmed.toLowerCase();
    const firstUpper = lower.charAt(0).toUpperCase() + lower.slice(1);
    const upper = trimmed.toUpperCase();

    return Array.from(new Set([trimmed, lower, firstUpper, upper])).filter(
      Boolean
    );
  }

  getUserFromEmail(email: string) {
    const trimmed = String(email || '').trim();
    const normalized = trimmed.toLowerCase();
    const exactValues = Array.from(new Set([trimmed, normalized])).filter(Boolean);
    const queries = [
      ...exactValues.map((value) =>
        this.afs
          .collection<User>(`users`, (ref) => ref.where('email', '==', value))
          .valueChanges()
      ),
      this.afs
        .collection<User>(`users`, (ref) => ref.where('emailLower', '==', normalized))
        .valueChanges(),
    ];

    return combineLatest(queries).pipe(
      map((results) => {
        const seen = new Set<string>();
        return results.flat().filter((user) => {
          const key = user.uid || user.email || user.emailLower || '';
          if (!key || seen.has(key)) return false;
          seen.add(key);
          return true;
        });
      })
    );
  }

  /** Resolve many presence-directory entries with a few one-shot reads. */
  async getUsersByEmailsOnce(emails: string[]): Promise<User[]> {
    const exactEmails = Array.from(
      new Set(
        (emails || [])
          .flatMap((email) => {
            const exact = String(email || '').trim();
            return [exact, exact.toLowerCase()];
          })
          .filter(Boolean)
      )
    );
    const normalizedEmails = Array.from(
      new Set(exactEmails.map((email) => email.toLowerCase()))
    );
    if (!normalizedEmails.length) return [];

    const chunksOfTen = (values: string[]): string[][] => {
      const chunks: string[][] = [];
      for (let index = 0; index < values.length; index += 10) {
        chunks.push(values.slice(index, index + 10));
      }
      return chunks;
    };

    const snapshots = await Promise.all(
      [
        ...chunksOfTen(normalizedEmails).map((chunk) =>
          this.afs
            .collection<User>('users', (ref) =>
              ref.where('emailLower', 'in', chunk)
            )
            .ref.get()
        ),
        ...chunksOfTen(exactEmails).map((chunk) =>
          this.afs
            .collection<User>('users', (ref) => ref.where('email', 'in', chunk))
            .ref.get()
        ),
      ]
    );

    const users = new Map<string, User>();
    snapshots.forEach((snapshot) => {
      snapshot.docs.forEach((document) => {
        const user = document.data() as User;
        const key =
          user.uid ||
          String(user.emailLower || user.email || '')
            .trim()
            .toLowerCase();
        if (key) users.set(key, user);
      });
    });
    return Array.from(users.values());
  }

  getAllOtherUsers(email: string) {
    return this.afs
      .collection<User>(`users`, (ref) =>
        ref.where('email', '!=', email).limit(10)
      )
      .valueChanges();
  }

  addNewUser(
    firstName: string,
    lastName: string,
    user: any,
    goal: string,
    sdgsSelected: string[]
  ) {
    const userRef: AngularFirestoreDocument<User> = this.afs.doc(
      `users/${user.uid}`
    );
    const data = {
      uid: user.uid,
      email: user.email,
      emailLower: (user.email || '').toLowerCase(),
      firstName: firstName,
      firstNameLower: (firstName || '').toLowerCase(),
      lastName: lastName,
      lastNameLower: (lastName || '').toLowerCase(),
      followers: '0',
      following: '0',
      employement: '',
      status: '',
      profileCredential: '',
      profileDescription: '',
      education: '',
      location: '',
      profilePicture: {},
      dateJoined: this.time.getCurrentDate(),
      contentViews: '0',
      goal: goal,
      sdgsSelected: sdgsSelected,
      profilePicPath: '',
    };
    return userRef.set(data, { merge: true });
  }

  logout() {
    this.email = of('');
    this.fireauth
      .signOut()
      .then(
        () => {
          // this.updateStatusOffline();
          this.router.navigate(['/']);
        },
        (err) => {
          alert(err.message);
        }
      )
      .catch((error) => {
        alert('Something went wrong');
        this.router.navigate(['/']);
        // ...
      });
  }

  async SignIn(email: string, password: string): Promise<void> {
    this.logingError = of(null);
    try {
      const cred = await this.fireauth.signInWithEmailAndPassword(
        email,
        password
      );
      await this.finishInteractiveSignIn(cred.user ?? null);
    } catch (err) {
      this.logingError = of(err);
      throw err;
    }
  }

  async signInWithGoogle(): Promise<void> {
    this.logingError = of(null);
    const provider = new firebase.auth.GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    try {
      const cred = await this.fireauth.signInWithPopup(provider);
      if (cred.user) {
        await this.ensureUserProfileDocument(cred.user);
      }
      await this.finishInteractiveSignIn(cred.user ?? null);
    } catch (err) {
      this.logingError = of(err);
      throw err;
    }
  }

  async signInWithFacebook(): Promise<void> {
    this.logingError = of(null);
    const provider = new firebase.auth.FacebookAuthProvider();
    provider.addScope('email');
    try {
      const cred = await this.fireauth.signInWithPopup(provider);
      if (cred.user) {
        await this.ensureUserProfileDocument(cred.user);
      }
      await this.finishInteractiveSignIn(cred.user ?? null);
    } catch (err) {
      this.logingError = of(err);
      throw err;
    }
  }

  async signInWithTwitter(): Promise<void> {
    this.logingError = of(null);
    const provider = new firebase.auth.TwitterAuthProvider();
    provider.setCustomParameters({ include_email: 'true' });
    try {
      const cred = await this.fireauth.signInWithPopup(provider);
      if (cred.user) {
        await this.ensureUserProfileDocument(cred.user);
      }
      await this.finishInteractiveSignIn(cred.user ?? null, {
        fallbackVerify: true,
      });
    } catch (err) {
      this.logingError = of(err);
      throw err;
    }
  }

  async signInWithApple(): Promise<void> {
    this.logingError = of(null);
    const provider = new firebase.auth.OAuthProvider('apple.com');
    provider.addScope('email');
    provider.addScope('name');
    provider.setCustomParameters({ locale: 'en_US' });
    try {
      const cred = await this.fireauth.signInWithPopup(provider);
      const givenName =
        (cred.additionalUserInfo?.profile as { given_name?: string } | null)
          ?.given_name || '';
      const familyName =
        (cred.additionalUserInfo?.profile as { family_name?: string } | null)
          ?.family_name || '';
      if (cred.user && !cred.user.displayName && (givenName || familyName)) {
        await cred.user.updateProfile({
          displayName: `${givenName} ${familyName}`.trim(),
        });
      }
      if (cred.user) {
        await this.ensureUserProfileDocument(cred.user);
      }
      await this.finishInteractiveSignIn(cred.user ?? null);
    } catch (err) {
      this.logingError = of(err);
      throw err;
    }
  }

  async signInWithMicrosoft(): Promise<void> {
    this.logingError = of(null);
    const provider = new firebase.auth.OAuthProvider('microsoft.com');
    provider.addScope('User.Read');
    provider.setCustomParameters({
      prompt: 'consent',
      tenant: 'common',
    });

    try {
      const cred = await this.fireauth.signInWithPopup(provider);
      const profile =
        (cred.additionalUserInfo?.profile as { displayName?: string } | null) ||
        null;
      if (cred.user && !cred.user.displayName && profile?.displayName) {
        await cred.user.updateProfile({
          displayName: profile.displayName,
        });
      }
      if (cred.user) {
        await this.ensureUserProfileDocument(cred.user);
      }
      await this.finishInteractiveSignIn(cred.user ?? null);
    } catch (err) {
      this.logingError = of(err);
      throw err;
    }
  }

  async forgotPassword(email: string): Promise<void> {
    (await this.fireauth.app).auth().languageCode = getLanguage();
    return this.fireauth.sendPasswordResetEmail(email);
  }
  private col = this.afs.collection<DemoBooking>('demoBookings');
  /** Write one booking and return the document reference */
  addDemoScheduled(
    booking: DemoBooking
  ): Promise<DocumentReference<DemoBooking>> {
    return this.col.add({
      ...booking,
      createdAt: serverTimestamp() as any, // keeps clock authority on server
    });
  }

  updateDemoBooking(
    id: string,
    booking: Partial<DemoBooking>
  ): Promise<void> {
    return this.afs.doc<DemoBooking>(`demoBookings/${id}`).update({
      ...booking,
      updatedAt: serverTimestamp() as any,
    } as any);
  }

  deleteDemoBooking(id: string): Promise<void> {
    return this.afs.doc<DemoBooking>(`demoBookings/${id}`).delete();
  }

  /** Live list for the admin component, ordered by slot */
  listAll() {
    return this.afs
      .collection<DemoBooking>('demoBookings', (ref) =>
        ref.orderBy('demoDateTime', 'asc')
      )
      .valueChanges({ idField: 'id' });
  }

  listGsl2026PrepBookings() {
    return this.afs
      .collection<DemoBooking>('demoBookings', (ref) =>
        ref.where('bookingType', '==', 'gsl2026Prep')
      )
      .valueChanges({ idField: 'id' });
  }

  getGslPrepEmailTemplate() {
    return this.afs
      .doc<GslPrepEmailTemplate>(this.gslPrepEmailTemplateDoc)
      .valueChanges();
  }

  saveGslPrepEmailTemplate(template: GslPrepEmailTemplate): Promise<void> {
    return this.afs.doc<GslPrepEmailTemplate>(this.gslPrepEmailTemplateDoc).set(
      {
        ...template,
        updatedAt: serverTimestamp() as any,
        updatedBy: this.currentUser?.email || '',
      },
      { merge: true }
    );
  }

  addNewUserSchoolAdmin(
    firstName: string,
    lastName: string,
    user: any,
    goal: string,
    sdgsSelected: string[],

    role: 'individual' | 'schoolAdmin' = 'individual',
    schoolId?: string
  ) {
    const userRef: AngularFirestoreDocument<User> = this.afs.doc(
      `users/${user.uid}`
    );
    const data = {
      uid: user.uid,
      email: user.email,
      emailLower: (user.email || '').toLowerCase(),
      firstName: firstName,
      firstNameLower: (firstName || '').toLowerCase(),
      lastName: lastName,
      lastNameLower: (lastName || '').toLowerCase(),
      followers: '0',
      following: '0',
      employement: '',
      status: '',
      profileCredential: '',
      profileDescription: '',
      education: '',
      location: '',
      profilePicture: {},
      dateJoined: this.time.getCurrentDate(),
      contentViews: '0',
      goal: goal,
      sdgsSelected: sdgsSelected,
      profilePicPath: '',
      role,
      schoolId: schoolId || '',
    };
    return userRef.set(data, { merge: true });
  }
  /** AuthService */
  registerSchool(
    firstName: string,
    lastName: string,
    email: string,
    password: string,
    schoolName: string,
    meta?: RegisterSchoolMeta
  ): Promise<void> {
    return this.fireauth
      .createUserWithEmailAndPassword(email, password)
      .then(async (cred) => {
        await this.sendEmailForVerification(cred.user);

        // ---- derive pricing server-side (do NOT trust client) ----
        const plan: PlanKey = meta?.plan ?? 'tournament'; // sensible default
        const basePrice = PRICE_BOOK[plan];
        const extraTeams = Math.max(0, meta?.extraTeams ?? 0);
        const currency = meta?.currency || 'USD';
        const addOns = extraTeams * 30;
        const total = basePrice + addOns;

        // 1) create school doc
        const schoolRef = this.afs.collection('schools').doc();
        await schoolRef.set({
          id: schoolRef.ref.id,
          name: schoolName,
          ownerUid: cred.user!.uid,
          createdAt: this.time.getCurrentDate(),

          // optional metadata
          meta: {
            country: meta?.schoolCountry || null,
            type: meta?.schoolType || null,
            website: meta?.schoolWebsite || null,
            courseType: meta?.courseType || null,
            coursePurpose: meta?.coursePurpose || null,
            specificFocus: meta?.specificFocus || null, // NEW
          },

          // billing snapshot at signup
          billing: {
            plan,
            currency,
            basePrice,
            extraTeams,
            addOns,
            total,
            paymentStatus: basePrice === 0 ? 'paid' : 'pending', // free = auto-paid
            // you can add: checkoutSessionId, provider, etc.
          },
        });

        // 2) create admin user tied to the school
        await this.addNewUserSchoolAdmin(
          firstName,
          lastName,
          cred.user,
          '',
          [],
          'schoolAdmin',
          schoolRef.ref.id
        );
      })
      .catch((err) => {
        throw err;
      });
  }

  getSchoolDoc(id: string) {
    return this.afs.doc<School>(`schools/${id}`).valueChanges();
  }

  getStudentsInSchool(schoolId: string) {
    return this.afs
      .collection<User>(
        'users',
        (ref) =>
          ref.where('schoolId', '==', schoolId).where('role', '==', 'student') // admins excluded
      )
      .valueChanges();
  }
  // AuthService additions
  async getUid(): Promise<string | null> {
    const u = await this.fireauth.currentUser;
    return u?.uid ?? null;
  }

  /**
   * Check if the current user's email is verified.
   * Reloads the user to get the latest verification status from Firebase.
   */
  async isEmailVerified(): Promise<boolean> {
    const user = await this.fireauth.currentUser;
    if (!user) return false;
    // Reload to get the latest status from Firebase
    await user.reload();
    return user.emailVerified;
  }

  /**
   * Resend verification email to the current user.
   */
  async resendVerificationEmail(): Promise<void> {
    const user = await this.fireauth.currentUser;
    if (user && !user.emailVerified) {
      await this.sendEmailForVerification(user);
    }
  }

  /**
   * Refreshes Firebase user and syncs verified flag to Firestore.
   * Returns true if the user is verified after refresh.
   */
  async syncEmailVerified(): Promise<boolean> {
    const user = await this.fireauth.currentUser;
    if (!user) return false;
    await user.reload();
    if (!user.emailVerified) return false;
    await user.getIdToken(true);
    try { await this.markUserVerified(user.uid); } catch (error) { console.warn('Verified account profile sync will retry later.', error); }
    return true;
  }

  async fetchSignInMethods(email: string): Promise<string[]> {
    return this.fireauth.fetchSignInMethodsForEmail(email);
  }

  // Silent sign-in that RETURNS uid and DOES NOT navigate
  async signInForCheckout(email: string, password: string): Promise<string> {
    const cred = await this.fireauth.signInWithEmailAndPassword(
      email,
      password
    );
    await this.updateLastLogin(cred.user ?? null);
    return cred.user!.uid;
  }

  async createAuthUserOnly(
    firstName: string,
    lastName: string,
    email: string,
    password: string
  ): Promise<string> {
    const cred = await this.fireauth.createUserWithEmailAndPassword(
      email,
      password
    );
    await this.sendEmailForVerification(cred.user);

    // optional: create a user profile document now
    await this.afs.doc(`users/${cred.user!.uid}`).set(
      {
        uid: cred.user!.uid,
        firstName,
        firstNameLower: (firstName || '').toLowerCase(),
        lastName,
        lastNameLower: (lastName || '').toLowerCase(),
        email,
        emailLower: (email || '').toLowerCase(),
        role: 'schoolAdmin', // provisional
        createdAt: this.time.getCurrentDate(),
        status: 'pendingPayment',
        dateJoined: this.time.getCurrentDate(),
      },
      { merge: true }
    );

    return cred.user!.uid;
  }
  // Sign-in helpers
  private async finishInteractiveSignIn(
    user: firebase.User | null,
    opts: { fallbackVerify?: boolean } = {}
  ): Promise<void> {
    if (!user) {
      return;
    }

    await this.updateLastLogin(user);

    // Repair profile documents for users whose Auth account was created while
    // Firestore writes were unavailable. A login should never be reported as a
    // bad password merely because this secondary profile sync fails.
    try {
      await this.ensureUserProfileDocument(user);
    } catch (error) {
      console.warn('Unable to ensure user profile during sign-in:', user.uid, error);
    }

    const providerIds = user.providerData
      .map((p) => p?.providerId)
      .filter((id): id is string => !!id);
    const isSocialProvider = providerIds.some((pid) => pid !== 'password');
    const consideredVerified =
      user.emailVerified || isSocialProvider || opts.fallbackVerify === true;

    if (consideredVerified) {
      try {
        await this.markUserVerified(user.uid);
      } catch (error) {
        console.warn('Unable to sync verified profile flag:', user.uid, error);
      }
      const dest = this.popRedirect();
      this.navigateToDestination(dest);
    } else if (gameAuthReturn()) {
      this.navigateToDestination(this.popRedirect());
    } else {
      this.router.navigate(['/verify-email'], {queryParams: {redirectTo: captureAuthReturn()}});
    }
  }

  private navigateToDestination(target: string) { navigateAuthReturn(this.router, target); }

  private async markUserVerified(uid: string): Promise<void> {
    const userRef = this.afs.doc<User>(`users/${uid}`);
    const snap = await userRef.ref.get();
    const data = snap.data();
    if (!data?.verified) {
      await userRef.set({ verified: true } as Partial<User>, { merge: true });
    }
  }

  private async updateLastLogin(user: firebase.User | null): Promise<void> {
    if (!user?.uid) return;
    const lastSignInTime = user.metadata?.lastSignInTime;
    const parsedMs = lastSignInTime ? Date.parse(lastSignInTime) : NaN;
    const iso = Number.isFinite(parsedMs)
      ? new Date(parsedMs).toISOString()
      : new Date().toISOString();
    try {
      await this.afs.doc<User>(`users/${user.uid}`).set(
        {
          lastLogin: iso,
        } as Partial<User>,
        { merge: true }
      );
    } catch (error) {
      console.warn('Unable to persist lastLogin for user:', user.uid, error);
    }
  }

  private initLastActiveTracking() {
    this.fireauth.authState.subscribe((authUser) => {
      const nextUid = authUser?.uid ?? null;
      this.currentAuthUid = nextUid;
      if (nextUid !== this.activeUid) {
        this.activeUid = nextUid;
        this.lastActiveWriteAtMs = 0;
      }
      this.presence.setCurrentUser(nextUid);
      if (nextUid) {
        void this.writeLastActive(nextUid, true);
      }
    });

    if (this.activityTrackingBound || typeof window === 'undefined') return;

    const onActiveSignal = () => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') {
        return;
      }
      if (this.activeUid) {
        void this.writeLastActive(this.activeUid, false);
      }
    };

    window.addEventListener('focus', onActiveSignal);
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', onActiveSignal);
    }
    this.activityTrackingBound = true;
  }

  private async writeLastActive(uid: string, force: boolean): Promise<void> {
    const nowMs = Date.now();
    if (
      !force &&
      nowMs - this.lastActiveWriteAtMs < this.minLastActiveWriteIntervalMs
    ) {
      return;
    }

    this.lastActiveWriteAtMs = nowMs;
    try {
      const touchLastActive = this.fns.httpsCallable('touchLastActive');
      await firstValueFrom(touchLastActive({}));
    } catch (error) {
      console.warn('touchLastActive callable failed, using client fallback', error);
      try {
        await this.afs.doc<User>(`users/${uid}`).set(
          {
            lastActiveAt: new Date(nowMs).toISOString(),
          } as Partial<User>,
          { merge: true }
        );
      } catch (fallbackError) {
        console.warn(
          'Unable to persist lastActiveAt for user:',
          uid,
          fallbackError
        );
      }
    }
  }

  private async ensureUserProfileDocument(user: firebase.User): Promise<void> {
    const userRef = this.afs.doc<User>(`users/${user.uid}`);
    const snap = await userRef.ref.get();
    const email =
      user.email ||
      user.providerData.find((p) => !!p?.email)?.email ||
      '';
    const displayName = user.displayName?.trim() || '';
    const [firstRaw, ...rest] = displayName.split(' ').filter(Boolean);
    // Never invent a person's name from their email address. Social providers
    // normally supply displayName; password accounts can complete a real name
    // through Get Started or profile editing.
    const firstName = firstRaw || '';
    const lastName = rest.join(' ');

    if (!snap.exists) {
      await userRef.set(
        {
          uid: user.uid,
          email,
          emailLower: (email || '').toLowerCase(),
          firstName,
          firstNameLower: (firstName || '').toLowerCase(),
          lastName,
          lastNameLower: (lastName || '').toLowerCase(),
          followers: '0',
          following: '0',
          employement: '',
          status: '',
          profileCredential: '',
          profileDescription: '',
          education: '',
          location: '',
          profilePicture: {},
          dateJoined: this.time.getCurrentDate(),
          contentViews: '0',
          goal: '',
          sdgsSelected: [],
          profilePicPath: '',
        },
        { merge: true }
      );
      return;
    }

    const current = snap.data() as User | undefined;
    const updates: Partial<User> = {};

    if (email && !current?.email) {
      updates.email = email;
    }
    if (email && current?.emailLower !== email.toLowerCase()) {
      updates.emailLower = email.toLowerCase();
    }
    if (!current?.firstName && firstName) {
      updates.firstName = firstName;
    }
    if (firstName && current?.firstNameLower !== firstName.toLowerCase()) {
      updates.firstNameLower = firstName.toLowerCase();
    }
    if (!current?.lastName && lastName) {
      updates.lastName = lastName;
    }
    if (lastName && current?.lastNameLower !== lastName.toLowerCase()) {
      updates.lastNameLower = lastName.toLowerCase();
    }

    if (Object.keys(updates).length) {
      await userRef.set(updates, { merge: true });
    }
  }

  private deriveNameFromEmail(email: string): string {
    if (!email) {
      return '';
    }
    const [localPart] = email.split('@');
    if (!localPart) {
      return '';
    }
    return localPart.replace(/[._-]+/g, ' ').trim();
  }

  // AuthService
  userDoc$(uid: string) {
    return this.afs.doc<any>(`users/${uid}`).valueChanges();
  }

  schoolDoc$(schoolId: string) {
    return this.afs.doc<any>(`schools/${schoolId}`).valueChanges();
  }

  /**
   * Check if a user exists by email and return their data (first match).
   * Returns null if no user found.
   */
  async getUserByEmail(email: string): Promise<User | null> {
    const snapshot = await this.afs
      .collection<User>('users', (ref) => ref.where('email', '==', email))
      .get()
      .toPromise();
    if (!snapshot || snapshot.empty) {
      return null;
    }
    return snapshot.docs[0].data() as User;
  }

  /**
   * Upgrade an existing user to school admin and create a school for them.
   * The user must already exist and have a verified email.
   * Returns the school ID on success.
   */
  async upgradeToSchoolAdmin(
    uid: string,
    schoolName: string,
    meta?: RegisterSchoolMeta
  ): Promise<string> {
    // Check if user already has a school
    const userRef = this.afs.doc<User>(`users/${uid}`);
    const userSnap = await userRef.ref.get();
    const userData = userSnap.data() as User | undefined;

    if (userData?.schoolId) {
      // Check if they own a school already
      const schoolSnap = await this.afs
        .doc(`schools/${userData.schoolId}`)
        .ref.get();
      const schoolData = schoolSnap.data() as any;
      if (schoolData?.ownerUid === uid) {
        throw new Error('You already own a school account.');
      }
    }

    // Derive pricing (same logic as registerSchool)
    const plan: PlanKey = meta?.plan ?? 'tournament';
    const basePrice = PRICE_BOOK[plan];
    const extraTeams = Math.max(0, meta?.extraTeams ?? 0);
    const currency = meta?.currency || 'USD';
    const addOns = extraTeams * 30;
    const total = basePrice + addOns;

    // Create school doc
    const schoolRef = this.afs.collection('schools').doc();
    await schoolRef.set({
      id: schoolRef.ref.id,
      name: schoolName,
      ownerUid: uid,
      createdAt: this.time.getCurrentDate(),
      meta: {
        country: meta?.schoolCountry || null,
        type: meta?.schoolType || null,
        website: meta?.schoolWebsite || null,
        courseType: meta?.courseType || null,
        coursePurpose: meta?.coursePurpose || null,
        specificFocus: meta?.specificFocus || null,
      },
      billing: {
        plan,
        currency,
        basePrice,
        extraTeams,
        addOns,
        total,
        paymentStatus: basePrice === 0 ? 'paid' : 'pending',
      },
    });

    // Update user to be schoolAdmin and link to school
    await userRef.set(
      {
        role: 'schoolAdmin',
        schoolId: schoolRef.ref.id,
      },
      { merge: true }
    );

    return schoolRef.ref.id;
  }

  // AuthService
  private popRedirect(): string {
    // 1) in-memory (setRedirectUrl called by guards or components)
    let target = (this.redirectUrl || '').trim();

    // 2) query param on the current URL (e.g. /login?redirectTo=/avatar/albert-einstein)
    if (!target) {
      const tree = this.router.parseUrl(this.router.url);
      const qp = tree.queryParams?.['redirectTo'];
      if (qp) {
        try {
          target = decodeURIComponent(qp);
        } catch {
          target = qp;
        }
      }
    }

    // 3) sessionStorage fallback (survives refresh)
    if (!target) {
      const ss = sessionStorage.getItem('redirectTo');
      if (ss) {
        try {
          target = decodeURIComponent(ss);
        } catch {
          target = ss;
        }
        sessionStorage.removeItem('redirectTo');
      }
    }

    // sanitize + clear
    target = safeAuthReturn(target) || '';
    if (!target) {
      // Check if user is school admin and redirect accordingly
      if (this.currentUser?.role === 'schoolAdmin') {
        target = '/school-admin';
      } else {
        target = '/home';
      }
    }
    this.redirectUrl = '';
    return target;
  }
}
