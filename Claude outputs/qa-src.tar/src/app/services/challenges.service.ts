import { Injectable } from '@angular/core';
import {
  AngularFirestore,
  AngularFirestoreDocument,
} from '@angular/fire/compat/firestore';
import { AngularFireFunctions } from '@angular/fire/compat/functions';
import { BehaviorSubject, Observable, firstValueFrom, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { ChallengeJoinRequest, ChallengePage } from '../models/user';
import { AuthService } from './auth.service';
import { TimeService } from './time.service';
import { SolutionService } from './solution.service';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';

export interface FeaturedChallengeSpaceConfig {
  featuredSpaceId: string;
  featuredSpaceTitle?: string;
  updatedAt?: any;
  updatedBy?: {
    uid?: string;
    email?: string;
    name?: string;
  };
}

export interface ResolvedChallengePage {
  id: string;
  data: ChallengePage;
  loadedByCustomUrl: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class ChallengesService {
  private readonly challengeSpacesSettingsDocPath =
    'admin_settings/challenge_spaces';

  constructor(
    private afs: AngularFirestore,
    private fns: AngularFireFunctions,
    private auth: AuthService,
    private time: TimeService,
    private solution: SolutionService
  ) {}
  private selectedChallengeItemSource = new BehaviorSubject<any>(null);
  selectedChallengeItem$ = this.selectedChallengeItemSource.asObservable();

  setSelectedChallengeItem(challengeItem: any) {
    this.selectedChallengeItemSource.next(challengeItem);
    this.saveSelectedChallengeItemToStorage(challengeItem);
  }
  saveSelectedChallengeItemToStorage(challengeItem: any) {
    localStorage.setItem(
      'selectedChallengeItem',
      JSON.stringify(challengeItem)
    );
  }

  getSelectedChallengeItemFromStorage() {
    const storedItem = localStorage.getItem('selectedChallengeItem');
    return storedItem ? JSON.parse(storedItem) : null;
  }
  clearSelectedChallengeItem() {
    this.selectedChallengeItemSource.next(null);
    localStorage.removeItem('selectedChallengeItem');
  }
  getAllChallenges() {
    return this.afs.collection('challenges').valueChanges(); // Retrieves all challenges
  }
  // getThisUserChallenges(
  //   userId: string,
  // ): Observable<any[]> {
  //   if (userId) {
  //     return this.afs
  //       .collection('user-challenges', (ref) =>
  //         ref.where('authorId', '==', userId)
  //       )
  //       .valueChanges();
  //   } else {
  //     // Return an empty array if the user is not authenticated
  //     return of([]);
  //   }
  // }

  getThisUserChallenges(
    userId: string,
    challengePageId: string
  ): Observable<any[]> {
    if (userId) {
      return this.afs
        .collection('user-challenges', (ref) =>
          ref
            .where('authorId', '==', userId)
            .where('challengePageId', '==', challengePageId)
        )
        .valueChanges();
    } else {
      // Return an empty array if the user is not authenticated
      return of([]);
    }
  }

  getChallengeById(challengeId: string) {
    return this.afs.doc(`challenges/${challengeId}`).valueChanges();
  }

  getChallengesByCategory(category: string) {
    return this.afs
      .collection('challenges', (ref) => ref.where('category', '==', category))
      .valueChanges();
  }
  getUserChallengesByCategory(category: string) {
    return this.afs
      .collection('user-challenges', (ref) =>
        ref.where('category', '==', category)
      )
      .valueChanges();
  }

  getUserChallengesForPage(challengePageId: string): Observable<any[]> {
    if (!challengePageId) {
      return of([]);
    }

    return this.afs
      .collection('user-challenges', (ref) =>
        ref.where('challengePageId', '==', challengePageId)
      )
      .valueChanges({ idField: 'docId' } as any);
  }

  async getUserChallengesForPageOnce(challengePageId: string): Promise<any[]> {
    if (!challengePageId) {
      return [];
    }

    const snapshot = await this.afs
      .collection('user-challenges', (ref) =>
        ref.where('challengePageId', '==', challengePageId)
      )
      .ref.get({ source: 'server' });

    return snapshot.docs.map((doc) => ({
      ...(doc.data() as Record<string, any>),
      docId: doc.id,
    }));
  }
  extractCategories() {
    this.afs
      .collection('challenges')
      .valueChanges()
      .subscribe((challenges: any[]) => {
        // Extract categories and ensure uniqueness
        const uniqueCategories = Array.from(
          new Set(challenges.map((challenge) => challenge.category))
        );
        return uniqueCategories;
      });
  }
  extractUserCategories() {
    this.afs
      .collection('user-challenges')
      .valueChanges()
      .subscribe((challenges: any[]) => {
        // Extract categories and ensure uniqueness
        const uniqueCategories = Array.from(
          new Set(challenges.map((challenge) => challenge.category))
        );
        return uniqueCategories;
      });
  }

  addChallenge(challenge: {
    id: string;
    title: string;
    description: string;
    category: string;
    image: string;
  }) {
    const challengeRef: AngularFirestoreDocument<any> = this.afs.doc(
      `challenges/${challenge.id}`
    );
    const data = {
      id: challenge.id,
      title: challenge.title,
      description: challenge.description,
      category: challenge.category,
      image: challenge.image,
    };
    return challengeRef.set(data, { merge: true });
  }
  addUserChallenge(challenge: {
    id: string;
    title: string;
    description: string;
    category: string;
    image: string;
    challengePageId: any;
  }): Promise<void> {
    const user = this.auth.currentUser;
    if (user && user.uid) {
      const challengeRef: AngularFirestoreDocument<any> = this.afs.doc(
        `user-challenges/${challenge.id}`
      );
      const data = {
        id: challenge.id,
        title: challenge.title,
        description: challenge.description,
        category: challenge.category,
        image: challenge.image,
        authorId: user.uid,
        addedByUid: user.uid,
        challengePageId: challenge.challengePageId,
      };
      return challengeRef.set(data, { merge: true });
    } else {
      // Reject the promise if the user is not authenticated
      return Promise.reject('User not authenticated');
    }
  }

  addParticipantToChallengePage(challengeId: string, participants: string[]) {
    const challengeRef: AngularFirestoreDocument<any> = this.afs.doc(
      `challengePages/${challengeId}`
    );
    const data = {
      participants: participants,
    };
    return challengeRef.set(data, { merge: true });
  }

  getChallengeJoinRequests(): Observable<ChallengeJoinRequest[]> {
    return this.afs
      .collection<ChallengeJoinRequest>('challengeJoinRequests', (ref) =>
        ref.where('status', '==', 'pending')
      )
      .valueChanges({ idField: 'id' } as any);
  }

  getMyChallengeJoinRequests(): Observable<ChallengeJoinRequest[]> {
    const email = String(this.auth.currentUser?.email || '')
      .trim()
      .toLowerCase();

    if (!email) {
      return of([]);
    }

    return this.afs
      .collection<ChallengeJoinRequest>('challengeJoinRequests', (ref) =>
        ref.where('requesterEmail', '==', email)
      )
      .valueChanges({ idField: 'id' } as any);
  }

  async requestToJoinChallengePage(
    challengePageId: string,
    message: string
  ): Promise<void> {
    const requestJoin = this.fns.httpsCallable('requestChallengePageJoin');
    await firstValueFrom(requestJoin({ challengePageId, message }));
  }

  async acceptChallengeJoinRequest(requestId: string): Promise<void> {
    const acceptJoin = this.fns.httpsCallable('acceptChallengePageJoinRequest');
    await firstValueFrom(acceptJoin({ requestId }));
  }

  async rejectChallengeJoinRequest(requestId: string): Promise<void> {
    const rejectJoin = this.fns.httpsCallable('rejectChallengePageJoinRequest');
    await firstValueFrom(rejectJoin({ requestId }));
  }

  deleteChallenge(challengeId: string) {
    return this.afs.doc(`challenges/${challengeId}`).delete();
  }
  deleteUserChallenge(challengeId: string) {
    return this.afs.doc(`user-challenges/${challengeId}`).delete();
  }
  async createChallengePage(challengePage: ChallengePage): Promise<void> {
    const user = this.auth.currentUser;
    if (user && user.uid) {
      const data: any = {
        challengePageId: challengePage.challengePageId,
        name: challengePage.name,
        heading: challengePage.heading,
        subHeading: challengePage.subHeading,
        description: challengePage.description,
        imageChallenge: challengePage.imageChallenge,
        logoImage: challengePage.logoImage,
        authorId: user.uid,
        restricted: challengePage.restricted,
        participants: challengePage.participants,
        creationDate: this.time.todaysDate(),
      };
      
      // Save schoolId if provided (for class mode)
      if ((challengePage as any).schoolId) {
        data.schoolId = (challengePage as any).schoolId;
      }

      const challengePageRef: AngularFirestoreDocument<ChallengePage> =
        this.afs.doc(`challengePages/${challengePage.challengePageId}`);

      await challengePageRef.set(data, { merge: true });
      // Asynchronously create the meeting link without awaiting
      this.solution
        .createMeetLink(challengePage.challengePageId!, challengePage.name!)
        .toPromise()
        .then((dataMeeting) => {
          const meetLink = dataMeeting.hangoutLink;
          console.log('Meeting link', meetLink);

          // Update the Firestore document with the meetLink
          return challengePageRef.update({ meetLink });
        })
        .catch((error) => {
          console.error('Error creating meeting link:', error);
          // Optionally handle the error, e.g., notify the user or retry
        });

      // Optionally return the solution data or a confirmation
      // return {
      //   status: 'Solution created. Meeting link is being generated.',
      // };
    } else {
      // Reject the promise if the user is not authenticated
      return Promise.reject('User not authenticated');
    }
  }
  getAllChallengePagesByThisUser(): Observable<ChallengePage[]> {
    const user = this.auth.currentUser;
    if (user && user.uid) {
      const currentUserId = user.uid;
      return this.afs
        .collection<ChallengePage>('challengePages', (ref) =>
          ref.where('authorId', '==', currentUserId)
        )
        .valueChanges();
    } else {
      // Return an empty array if the user is not authenticated
      return of([]);
    }
  }

  getAllChallengePages(): Observable<ChallengePage[]> {
    return this.afs
      .collection<ChallengePage>('challengePages')
      .valueChanges({ idField: 'id' } as any)
      .pipe(
        map((pages: any[]) =>
          (pages || []).map((page) => ({
            ...page,
            challengePageId: page.challengePageId || page.id,
          }))
        )
      );
  }

  getFeaturedChallengeSpaceConfig(): Observable<FeaturedChallengeSpaceConfig | null> {
    return this.afs
      .doc<FeaturedChallengeSpaceConfig>(this.challengeSpacesSettingsDocPath)
      .valueChanges()
      .pipe(
        map((config) =>
          config?.featuredSpaceId
            ? {
                ...config,
                featuredSpaceId: config.featuredSpaceId,
              }
            : null
        )
      );
  }

  setFeaturedChallengeSpace(space: ChallengePage | null): Promise<void> {
    const user = this.auth.currentUser || {};
    const authorName = [user.firstName, user.lastName]
      .filter(Boolean)
      .join(' ')
      .trim();
    const spaceTitle = space
      ? space.name || space.heading || 'Untitled challenge space'
      : '';

    const data: FeaturedChallengeSpaceConfig = {
      featuredSpaceId: space
        ? space.challengePageId || space.customUrl || spaceTitle
        : '',
      featuredSpaceTitle: spaceTitle,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
      updatedBy: {
        uid: user.uid || '',
        email: user.email || '',
        name: authorName || user.email || '',
      },
    };

    return this.afs
      .doc(this.challengeSpacesSettingsDocPath)
      .set(data, { merge: true });
  }

  // Get all challengePages where this user is participant
  getAllChallengesWhereUserIsParticipant(): Observable<ChallengePage[]> {
    const user = this.auth.currentUser;
    if (user && user.email) {
      const currentUserEmail = user.email;
      return this.afs
        .collection<ChallengePage>('challengePages', (ref) =>
          ref.where('participants', 'array-contains', currentUserEmail)
        )
        .valueChanges();
    } else {
      // Return an empty array if the user is not authenticated or no email
      return of([]);
    }
  }

  getChallengePageById(challengePageId: string) {
    return this.afs.doc(`challengePages/${challengePageId}`).valueChanges();
  }

  getChallengePageByCustomUrl(customUrl: string): Observable<ChallengePage | null> {
    return this.afs
      .collection<ChallengePage>('challengePages', (ref) =>
        ref.where('customUrl', '==', customUrl).limit(1)
      )
      .valueChanges()
      .pipe(
        map((pages) => (pages && pages.length > 0 ? pages[0] : null))
      );
  }

  async resolveChallengePage(
    idOrSlug: string
  ): Promise<ResolvedChallengePage | null> {
    const value = String(idOrSlug || '').trim();
    if (!value) {
      return null;
    }

    if (/^[A-Za-z0-9]{20}$/.test(value)) {
      const idSnapshot = await this.afs.doc<ChallengePage>(
        `challengePages/${value}`
      ).ref.get({ source: 'server' });
      if (idSnapshot.exists) {
        return {
          id: idSnapshot.id,
          data: idSnapshot.data() as ChallengePage,
          loadedByCustomUrl: false,
        };
      }
    }

    const customUrlSnapshot = await this.afs
      .collection<ChallengePage>('challengePages', (ref) =>
        ref.where('customUrl', '==', value).limit(1)
      )
      .ref.get({ source: 'server' });
    const customUrlDoc = customUrlSnapshot.docs[0];
    if (customUrlDoc) {
      return {
        id: customUrlDoc.id,
        data: customUrlDoc.data() as ChallengePage,
        loadedByCustomUrl: true,
      };
    }

    if (!/^[A-Za-z0-9]{20}$/.test(value)) {
      const idSnapshot = await this.afs.doc<ChallengePage>(
        `challengePages/${value}`
      ).ref.get({ source: 'server' });
      if (idSnapshot.exists) {
        return {
          id: idSnapshot.id,
          data: idSnapshot.data() as ChallengePage,
          loadedByCustomUrl: false,
        };
      }
    }

    return null;
  }

  async checkCustomUrlExists(customUrl: string, excludePageId?: string): Promise<boolean> {
    if (!customUrl || !customUrl.trim()) {
      return false;
    }
    
    const normalizedUrl = this.normalizeCustomUrl(customUrl);
    
    return new Promise((resolve) => {
      this.afs.collection<ChallengePage>('challengePages', (ref) =>
        ref.where('customUrl', '==', normalizedUrl)
      ).get().subscribe((snapshot) => {
        if (snapshot.empty) {
          resolve(false);
          return;
        }

        // If we're checking for an existing page (updating), exclude it from the check
        if (excludePageId) {
          const docs = snapshot.docs.filter(doc => doc.id !== excludePageId);
          resolve(docs.length > 0);
        } else {
          resolve(true);
        }
      });
    });
  }

  normalizeCustomUrl(url: string): string {
    return url
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9-]/g, '-') // Replace non-alphanumeric with hyphens
      .replace(/-+/g, '-') // Replace multiple hyphens with single hyphen
      .replace(/^-|-$/g, ''); // Remove leading/trailing hyphens
  }

  deleteChallengePage(challengePageId: string): Promise<void> {
    const challengePageRef: AngularFirestoreDocument<ChallengePage> =
      this.afs.doc(`challengePages/${challengePageId}`);

    return challengePageRef.delete();
  }
}
